import * as myFunctions from "./modules/functions.js";
myFunctions.isWebp();
